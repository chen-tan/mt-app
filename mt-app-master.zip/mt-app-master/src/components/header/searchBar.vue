<template>
    <div class="search-bar">
        search-bar
    </div>
</template>
<script>
export default {
    
}
</script>