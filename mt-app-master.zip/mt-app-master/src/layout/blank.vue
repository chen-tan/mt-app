<template>
    <div>
        dfsdf 
    </div>
</template>
<script>
export default {
    
}
</script>
<style scoped>
    *{
        color:blue;
    }
</style>